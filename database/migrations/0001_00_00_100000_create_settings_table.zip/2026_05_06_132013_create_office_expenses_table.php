<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('office_expenses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('institution_id')->constrained('institutions')->cascadeOnDelete();
            $table->foreignId('branch_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('account_id')->constrained('office_accounts')->cascadeOnDelete();
            $table->foreignId('head_id')->nullable()->constrained('office_heads')->nullOnDelete();
            $table->string('voucher_no')->nullable();
            $table->enum('pay_via', ['cash', 'card', 'bank', 'cheque', 'mobile_banking']);
            $table->string('reference')->nullable();
            $table->decimal('amount', 15, 2);
            $table->date('date');
            $table->text('description')->nullable();
            $table->string('attachment')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->timestamp('deleted_at_uniq')->nullable(false)->storedAs('COALESCE(deleted_at, "1970-01-01 00:00:01")');
            $table->unique(['institution_id', 'voucher_no', 'deleted_at_uniq'], 'office_expenses_institution_voucher_unique');
            $table->index(['institution_id', 'date']);
            $table->index(['institution_id', 'account_id', 'date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('office_expenses');
    }
};
