<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->foreignId('institution_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('branch_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('role', ['super_admin', 'ministry', 'admin', 'branch', 'staff', 'teacher', 'accountant', 'student', 'parent',])->default('student');
            $table->string('name', 100);
            $table->string('username', 100)->nullable();
            $table->string('phone', 15)->nullable();
            $table->string('email', 150)->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password', 255);
            $table->string('avatar', 255)->nullable();
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip', 45)->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
            $table->timestamp('deleted_at_uniq')->nullable(false)->storedAs('COALESCE(deleted_at, "1970-01-01 00:00:01")');

            $table->index(['institution_id', 'role', 'is_active'], 'users_institution_role_active_idx');
            $table->index(['branch_id', 'role'], 'users_branch_role_idx');

            // Soft-delete-safe uniqueness: plain unique() would permanently block
            // reuse of username/phone/email after a user is soft-deleted.
            $table->unique(['username', 'deleted_at_uniq'], 'users_username_deleted_at_unique');
            $table->unique(['phone', 'deleted_at_uniq'], 'users_phone_deleted_at_unique');
            $table->unique(['email', 'deleted_at_uniq'], 'users_email_deleted_at_unique');
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
