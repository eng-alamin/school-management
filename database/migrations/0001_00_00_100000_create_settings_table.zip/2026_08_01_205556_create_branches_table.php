<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('institution_id')->constrained()->cascadeOnDelete();
            // NOTE: a branch belongs only to an institution, not to another branch.
            // (A stray self-referencing branch_id column was previously added here
            // by mistake — likely from the bulk "add branch_id to every table" pass —
            // and has been removed.)

            $table->string('name');
            $table->string('code', 20); // e.g. MIR, UTR - used in ID generation, invoice prefix etc.
            $table->text('address')->nullable();
            $table->string('phone', 20)->nullable();
            $table->string('email')->nullable();
 
            // Marks the branch every fresh user session defaults to for this institution
            $table->boolean('is_main')->default(false);
            $table->boolean('is_active')->default(true);
 
            $table->softDeletes();
            $table->timestamp('deleted_at_uniq')->nullable(false)->storedAs('COALESCE(deleted_at, "1970-01-01 00:00:01")');
            $table->timestamps();

            $table->unique(['institution_id', 'code', 'deleted_at_uniq'], 'branches_institution_code_unique');
            $table->unique(['institution_id', 'name', 'deleted_at_uniq'], 'branches_institution_name_unique');
            $table->index(['institution_id', 'is_active'], 'branches_institution_active_idx');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('branches');
    }
};
