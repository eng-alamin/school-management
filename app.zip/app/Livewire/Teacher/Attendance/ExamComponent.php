<?php

namespace App\Livewire\Teacher\Attendance;

use Livewire\Component;
use App\Models\Attendance;
use App\Models\Student;
use App\Models\AcademicClass;
use App\Models\AcademicSection;
use App\Models\AcademicSubject;
use App\Models\AcademicClassAssign;
use App\Models\AcademicClassAssignDetail;
use App\Models\ExamSetup;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ExamComponent extends Component
{
    public $filterExam = '';
    public $filterClass = '';
    public $filterSection = '';
    public $filterSubject = '';

    public $subjects = [];

    public $data = [];
    public $hasAttendance = false;

    // Exam
    public function getExams()
    {
        return ExamSetup::where('is_published', 1)
            ->orderBy('name')
            ->get();
    }

    // Classes
    public function getAvailableClasses()
    {
        return AcademicClass::whereIn('id', AcademicClassAssign::distinct()->pluck('class_id'))
            ->orderBy('name')
            ->get();
    }

    // Sections
    public function getAvailableSections()
    {
        if (!$this->filterClass) return [];

        return AcademicSection::whereIn('id',
            AcademicClassAssign::where('class_id', $this->filterClass)
                ->whereNotNull('section_id')
                ->pluck('section_id')
        )->orderBy('name')->get();
    }

    /**
     * Class_id (ar optionally section_id) diye academic_class_assign_details
     * theke unique subject list ber kore — age JSON 'subjects' column theke ashto
     */
    protected function loadSubjects(): void
    {
        $query = AcademicClassAssignDetail::whereHas('classAssign', function ($q) {
            $q->where('class_id', $this->filterClass);

            if ($this->filterSection && $this->filterSection !== 'all') {
                $q->where('section_id', $this->filterSection);
            }
        });

        $subjectIds = $query->pluck('subject_id')->unique()->values();

        $this->subjects = $subjectIds->isNotEmpty()
            ? AcademicSubject::whereIn('id', $subjectIds)->orderBy('name')->get()
            : [];
    }

    public function updatedFilterClass()
    {
        $this->filterSection = '';
        $this->filterSubject = '';
        $this->subjects      = [];
        $this->data          = [];
        $this->hasAttendance = false;

        if (!$this->filterClass) return;

        $this->loadSubjects();
    }

    public function updatedFilterSection()
    {
        $this->filterSubject = '';
        $this->data          = [];
        $this->hasAttendance = false;

        if (!$this->filterClass || !$this->filterSection) return;

        $this->loadSubjects();
    }

    public function filter()
    {
        if (!$this->filterExam) {
            $this->dispatch('toast', type: 'error', message: 'Please select a exam.');
            return;
        }
        if (!$this->filterClass) {
            $this->dispatch('toast', type: 'error', message: 'Please select a class.');
            return;
        }
        if (!$this->filterSubject) {
            $this->dispatch('toast', type: 'error', message: 'Please select a subject.');
            return;
        }

        $studentsQuery = Student::where('class_id', $this->filterClass)
            ->orderBy('section_id')
            ->orderBy('roll_no');

        if ($this->filterSection && $this->filterSection !== 'all') {
            $studentsQuery->where('section_id', $this->filterSection);
        }

        $students = $studentsQuery->get();

        if ($students->isEmpty()) {
            $this->dispatch('toast', type: 'error', message: 'No Exam found.');
            $this->hasAttendance = false;
            return;
        }

        $sectionNames = AcademicSection::whereIn('id', $students->pluck('section_id')->unique())
            ->pluck('name', 'id');

        $existingQuery = Attendance::where('type', 'exam')
            ->where('exam_id', $this->filterExam)
            ->where('class_id', $this->filterClass)
            ->where('subject_id', $this->filterSubject);

        if ($this->filterSection && $this->filterSection !== 'all') {
            $existingQuery->where('section_id', $this->filterSection);
        }

        $existing = $existingQuery->get()->keyBy('attendable_id');

        $this->data = $students->map(function ($student) use ($existing, $sectionNames) {

            $att = $existing[$student->id] ?? null;

            return [
                'student_id'   => $student->id,
                'section_id'   => $student->section_id,
                'section_name' => $sectionNames[$student->section_id] ?? '',
                'name'         => $student->name,
                'roll_no'      => $student->roll_no,
                'register_no'  => $student->register_no,

                'status'       => $att->status ?? 'present',
                'remarks'      => $att->remarks ?? '',
            ];
        })->toArray();

        $this->hasAttendance = true;
    }

    public function save()
    {
        $this->validate([
            'filterExam'    => 'required',
            'filterClass'   => 'required',
            'filterSubject' => 'required',
        ]);

        $institutionId = institution()->id;

        DB::beginTransaction();
        try {
            foreach ($this->data as $item) {
                Attendance::updateOrCreate(
                    [
                        'attendable_id'   => $item['student_id'],
                        'attendable_type' => Student::class,
                        'type'            => 'exam',
                        'exam_id'         => $this->filterExam,
                        'class_id'        => $this->filterClass,
                        'section_id'      => $item['section_id'],
                        'subject_id'      => $this->filterSubject,
                    ],
                    [
                        'institution_id' => $institutionId,
                        'status'         => $item['status'],
                        'remarks'        => $item['remarks'],
                    ]
                );
            }

            DB::commit();
            $this->dispatch('toast', type: 'success', message: 'Attendance saved successfully!');

        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Teacher exam attendance save failed: ' . $e->getMessage());
            $this->dispatch('toast', type: 'error', message: 'Something went wrong while saving attendance.');
        }
    }

    public function resetForm()
    {
        $this->filterExam = '';
        $this->filterClass = '';
        $this->filterSection = '';
        $this->subjects = [];

        $this->data = [];
        $this->hasAttendance = false;

        $this->resetValidation();
    }

    public function render()
    {
        return view('livewire.teacher.attendance.exam-component')
            ->with('exams', $this->getExams())
            ->with('classes', $this->getAvailableClasses())
            ->with('sections', $this->getAvailableSections())
            ->with('subjects', $this->subjects)
            ->layout('layouts.teacher.app', [
                'title' => 'Exam Attendance | ' . institution()->name,
            ]);
    }
}