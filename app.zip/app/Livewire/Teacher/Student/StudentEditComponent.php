<?php

namespace App\Livewire\Teacher\Student;

use Livewire\Component;
use App\Models\User;
use App\Models\Student;
use App\Models\Guardian;
use App\Models\AcademicSession;
use App\Models\AcademicClass;
use App\Models\AcademicSection;
use App\Models\AcademicGroup;
use Illuminate\Support\Facades\DB;

use Illuminate\Validation\ValidationException;
use Illuminate\Validation\Rule;
use Livewire\WithFileUploads;

class StudentEditComponent extends Component
{
    use WithFileUploads;

    public $studentId;
    public $userId;
    public $student;
    public $guardian;

    public $session_id;
    public $register_no;
    public $roll_no;
    public $admission_date;
    public $class_id;
    public $section_id;
    public $group_id;

    public $name;
    public $gender;
    public $blood_group;
    public $dob;
    public $religion;
    public $mobile;
    public $email;
    public $present_address;
    public $permanent_address;

    public $student_photo;
    public $student_photo_upload;

    public $username;
    public $password;

    public $guardian_id;
    public $guardian_name, $guardian_relation;
    public $guardian_father_name, $guardian_mother_name;
    public $guardian_occupation, $guardian_income, $guardian_education;
    public $guardian_mobile, $guardian_email;
    public $guardian_address;

    public $guardian_photo;
    public $guardian_photo_upload;

    public $guardian_username;
    public $guardian_password;

    public $guardianUserId;

    public $previous_institution;
    public $qualification;
    public $remarks;

    public bool $guardian_exists = false;

    public function mount($id)
    {
        $this->studentId = $id;
        $this->student   = Student::with('user', 'guardians.user')->findOrFail($id);

        $this->userId = $this->student->user_id;

        // Academic
        $this->session_id     = $this->student->session_id;
        $this->register_no    = $this->student->register_no;
        $this->roll_no        = $this->student->roll_no;
        $this->admission_date = $this->student->admission_date;
        $this->class_id       = $this->student->class_id;
        $this->section_id     = $this->student->section_id;
        $this->group_id       = $this->student->group_id;

        // Personal
        $this->name              = $this->student->name;
        $this->gender            = $this->student->gender;
        $this->blood_group       = $this->student->blood_group;
        $this->dob               = $this->student->dob;
        $this->religion          = $this->student->religion;
        $this->mobile            = $this->student->mobile;
        $this->email             = $this->student->email;
        $this->present_address   = $this->student->present_address;
        $this->permanent_address = $this->student->permanent_address;

        $this->student_photo = $this->student->photo;

        // Login
        $this->username = $this->student->user->username;

        $this->guardian = $this->student->guardians->first();

        if ($this->guardian) {
            $this->guardian_exists = true;
            $this->guardian_id     = $this->guardian->id;
            $this->guardian_photo  = $this->guardian->photo;

            $this->guardianUserId = $this->guardian->user_id;

            $this->guardian_name        = $this->guardian->name;
            $this->guardian_relation    = $this->guardian->relation;
            $this->guardian_father_name = $this->guardian->father_name;
            $this->guardian_mother_name = $this->guardian->mother_name;
            $this->guardian_occupation  = $this->guardian->occupation;
            $this->guardian_income      = $this->guardian->income;
            $this->guardian_education   = $this->guardian->education;
            $this->guardian_mobile      = $this->guardian->mobile;
            $this->guardian_email       = $this->guardian->email;
            $this->guardian_address     = $this->guardian->address;
            $this->guardian_username    = $this->guardian->user->username ?? null;
        }

        // Previous Institution
        $this->previous_institution = $this->student->previous_institution;
        $this->qualification   = $this->student->qualification;
        $this->remarks         = $this->student->remarks;

        $this->dispatch('date-updated', date: $this->admission_date);
        $this->dispatch('date-updated', date: $this->dob);
    }

    public function rules()
    {
        return [
            'session_id'  => 'required',
            'register_no' => ['nullable', Rule::unique('students', 'register_no')->ignore($this->studentId)],
            'class_id'    => 'required',

            'name'        => 'required',

            'student_photo_upload'       => 'nullable',

            'username'    => ['required', Rule::unique('users', 'username')->ignore($this->userId)],
            'password'    => 'nullable',

            'guardian_id'       => $this->guardian_exists ? 'required' : 'nullable',
            'guardian_name'     => !$this->guardian_exists ? 'required' : 'nullable',
            'guardian_relation' => !$this->guardian_exists ? 'required' : 'nullable',
            'guardian_mobile'   => !$this->guardian_exists ? 'required' : 'nullable',

            'guardian_username' => !$this->guardian_exists
                ? ['required', Rule::unique('users', 'username')->ignore($this->guardianUserId)]
                : 'nullable',

            'guardian_photo_upload'       => 'nullable',
        ];
    }

    protected function failedValidation($validator)
    {
        $this->dispatch('validation-failed');
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName, $this->rules());
    }

    public function update()
    {
        DB::beginTransaction();

        try {

            $this->validate($this->rules());

            $institutionId = auth()->user()->institution_id;

            // ── Student user update ──────────────────────────────
            $userData = [
                'name'     => $this->name,
                'username' => $this->username,
                'email'    => $this->email,
            ];

            if (!empty($this->password)) {
                $userData['password'] = $this->password;
            }

            $user = User::findOrFail($this->userId);
            $user->update($userData);

            // ── Student record update ────────────────────────────
            $studentData = [
                'user_id'          => $user->id,

                'session_id'       => $this->session_id,
                'register_no'      => $this->register_no,
                'roll_no'          => $this->roll_no,
                'admission_date'   => $this->admission_date,
                'class_id'         => $this->class_id,
                'section_id'       => $this->section_id,
                'group_id'         => $this->group_id,

                'name'             => $this->name,
                'gender'           => $this->gender,
                'blood_group'      => $this->blood_group,
                'dob'              => $this->dob,
                'religion'         => $this->religion,
                'mobile'           => $this->mobile,
                'email'            => $this->email,
                'present_address'  => $this->present_address,
                'permanent_address'=> $this->permanent_address,

                'previous_institution'  => $this->previous_institution,
                'qualification'    => $this->qualification,
                'remarks'          => $this->remarks,
            ];

            if ($this->student_photo_upload) {
                $studentData['photo'] = $this->student_photo_upload->store('students', 'public');
            }

            $this->student->update($studentData);

            // ── Guardian ─────────────────────────────────────────
            if ($this->guardian_exists) {

                $this->student->guardians()->sync([
                    $this->guardian_id => [
                        'institution_id' => $institutionId,
                    ],
                ]);

            } elseif ($this->guardian) {
                $guardianUserData = [
                    'name'     => $this->guardian_name,
                    'username' => $this->guardian_username,
                    'email'    => $this->guardian_email,
                ];

                if (!empty($this->guardian_password)) {
                    $guardianUserData['password'] = $this->guardian_password;
                }

                User::findOrFail($this->guardian->user_id)->update($guardianUserData);

                $guardianData = [
                    'name'        => $this->guardian_name,
                    'relation'    => $this->guardian_relation,
                    'father_name' => $this->guardian_father_name,
                    'mother_name' => $this->guardian_mother_name,
                    'occupation'  => $this->guardian_occupation,
                    'income'      => $this->guardian_income,
                    'education'   => $this->guardian_education,
                    'mobile'      => $this->guardian_mobile,
                    'email'       => $this->guardian_email,
                    'address'     => $this->guardian_address,
                ];

                if ($this->guardian_photo_upload) {
                    $guardianData['photo'] = $this->guardian_photo_upload->store('guardians', 'public');
                }

                $this->guardian->update($guardianData);

                $this->student->guardians()->sync([
                    $this->guardian->id => [
                        'institution_id' => $institutionId,
                    ],
                ]);

            } else {

                // ── Student had NO guardian at all before — create a brand new one ──
                $guardianPassword = !empty($this->guardian_password)
                    ? $this->guardian_password
                    : '1234';

                $userGuardian = User::create([
                    'institution_id' => $institutionId,
                    'role'     => 'parent',
                    'name'     => $this->guardian_name,
                    'username' => $this->guardian_username,
                    'email'    => $this->guardian_email,
                    'password' => $guardianPassword,
                    'is_verified' => true,
                ]);

                $guardianData = [
                    'user_id'     => $userGuardian->id,
                    'name'        => $this->guardian_name,
                    'relation'    => $this->guardian_relation,
                    'father_name' => $this->guardian_father_name,
                    'mother_name' => $this->guardian_mother_name,
                    'occupation'  => $this->guardian_occupation,
                    'income'      => $this->guardian_income,
                    'education'   => $this->guardian_education,
                    'mobile'      => $this->guardian_mobile,
                    'email'       => $this->guardian_email,
                    'address'     => $this->guardian_address,
                ];

                if ($this->guardian_photo_upload) {
                    $guardianData['photo'] = $this->guardian_photo_upload->store('guardians', 'public');
                }

                $guardian = Guardian::create($guardianData);

                $this->student->guardians()->sync([
                    $guardian->id => [
                        'institution_id' => $institutionId,
                    ],
                ]);

                // Track it now, so a second submit in the same session updates in place too.
                $this->guardian       = $guardian;
                $this->guardianUserId = $userGuardian->id;
            }

            DB::commit();

            $this->dispatch('date-updated', date: $this->admission_date);
            $this->dispatch('date-updated', date: $this->dob);

            $this->dispatch('toast', type: 'success', message: 'Student updated successfully!');

        } catch (\Throwable $e) {

            DB::rollBack();

            $this->dispatch('toast', type: 'error', message: 'Something went wrong!');
            throw $e;
        }
    }

    public function render()
    {
        $sessions   = AcademicSession::orderBy('name')->get();
        $classes    = AcademicClass::orderBy('id')->get();
        $sections   = AcademicSection::orderBy('name')->get();
        $groups     = AcademicGroup::orderBy('name')->get();
        $guardians  = Guardian::orderBy('name')->get();

        return view('livewire.teacher.student.student-edit-component')
            ->with('sessions', $sessions)
            ->with('classes', $classes)
            ->with('sections', $sections)
            ->with('groups', $groups)
            ->with('guardians', $guardians)
            ->layout('layouts.teacher.app', [
                'title' => 'Edit Student | ' . institution()->name,
            ]);
    }
}