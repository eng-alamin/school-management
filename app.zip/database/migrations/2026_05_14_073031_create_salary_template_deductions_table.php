<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('salary_template_deductions', function (Blueprint $table) {
            $table->id();
 
            $table->foreignId('institution_id')->constrained()->cascadeOnDelete();
            $table->foreignId('salary_template_id')->constrained()->cascadeOnDelete();
 
            $table->string('name');
            $table->enum('type', ['fixed', 'percentage'])->default('fixed');
            $table->decimal('amount', 12, 2)->default(0); // fixed amount OR percentage value
 
            $table->timestamps();
 
            // Prevent duplicate deduction name within the same template
            $table->unique(['salary_template_id', 'name']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('salary_template_deductions');
    }
};
